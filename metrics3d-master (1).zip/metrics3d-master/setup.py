from setuptools import setup, find_packages

pkg_name = 'metrics_3d'
#Please use the install.py
#https://stackoverflow.com/questions/6323860/sibling-package-imports/50193944#50193944
setup(name=pkg_name, version='1.0', packages=find_packages())
