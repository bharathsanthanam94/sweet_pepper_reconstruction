# values from open3d DO NOT modify
# http://www.open3d.org/docs/release/python_api/open3d.geometry.Geometry.html
MESHTYPE = 6
TETRATYPE = 10
PCDTYPE = 1
